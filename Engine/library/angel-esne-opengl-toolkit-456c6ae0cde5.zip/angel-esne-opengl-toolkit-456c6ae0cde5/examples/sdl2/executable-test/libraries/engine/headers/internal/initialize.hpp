
// This is free code released into the public domain.
// Drafted by �ngel on January 2019.
// Use it at your own risk. It might have bugs.
// angel.rodriguez@esne.edu

#pragma once

namespace engine
{

    bool initialize (int subsystem);

}
